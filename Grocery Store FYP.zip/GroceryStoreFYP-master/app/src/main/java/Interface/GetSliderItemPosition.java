package Interface;

public interface GetSliderItemPosition {

    public  void getSlider(int position);

}
