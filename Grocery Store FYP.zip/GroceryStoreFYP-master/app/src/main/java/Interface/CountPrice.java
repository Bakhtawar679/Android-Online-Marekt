package Interface;

public interface CountPrice {


    public int getcount(double price, int number, boolean isAdd);
}
