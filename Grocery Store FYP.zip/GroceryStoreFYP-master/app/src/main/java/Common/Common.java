package Common;

import Models.UserModel;

public class Common {

    public static UserModel currentUser;
}
