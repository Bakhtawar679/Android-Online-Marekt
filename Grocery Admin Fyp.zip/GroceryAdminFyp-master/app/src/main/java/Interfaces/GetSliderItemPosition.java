package Interfaces;

public interface GetSliderItemPosition  {

    public  void getSlider(int position);

}
