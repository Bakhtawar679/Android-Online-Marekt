package Config;

public class Config {

    public static String content = "";
    public static String title = "";
    public static String imageUrl = "";
    public static String gameUrl = "";
}
